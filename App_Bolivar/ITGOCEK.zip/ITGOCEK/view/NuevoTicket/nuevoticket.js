
		$(document).ready(function() {
			$('#ticket_descrip').summernote({
                height: 150 
            });
		});
